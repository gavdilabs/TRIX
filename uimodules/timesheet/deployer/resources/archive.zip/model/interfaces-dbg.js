"use strict";

sap.ui.define([], function () {
  "use strict";

  /**
   * Controlled interface based on the model entities
   */
  /**
   * Tooling interface for allowing a Partial to consider nested structures
   */
  var Day = /*#__PURE__*/function (Day) {
    Day[Day["MONDAY"] = 1] = "MONDAY";
    Day[Day["TUESDAY"] = 2] = "TUESDAY";
    Day[Day["WEDNESDAY"] = 3] = "WEDNESDAY";
    Day[Day["THURSDAY"] = 4] = "THURSDAY";
    Day[Day["FRIDAY"] = 5] = "FRIDAY";
    Day[Day["SATURDAY"] = 6] = "SATURDAY";
    Day[Day["SUNDAY"] = 0] = "SUNDAY";
    return Day;
  }(Day || {});
  var __exports = {
    __esModule: true
  };
  __exports.Day = Day;
  return __exports;
});
//# sourceMappingURL=interfaces-dbg.js.map
