"use strict";

sap.ui.define([], function () {
  "use strict";

  let trix;
  (function (_trix2) {
    let admin;
    (function (_admin) {
      let SolutionType = /*#__PURE__*/function (SolutionType) {
        SolutionType[SolutionType["Standalone"] = 0] = "Standalone";
        SolutionType[SolutionType["S4"] = 1] = "S4";
        SolutionType[SolutionType["ECC"] = 2] = "ECC";
        SolutionType[SolutionType["SuccessFactors"] = 3] = "SuccessFactors";
        return SolutionType;
      }({});
      _admin.SolutionType = SolutionType;
      let ApprovalType = /*#__PURE__*/function (ApprovalType) {
        ApprovalType[ApprovalType["Manual"] = 0] = "Manual";
        ApprovalType[ApprovalType["BackgroundJob"] = 1] = "BackgroundJob";
        ApprovalType[ApprovalType["Auto"] = 3] = "Auto";
        ApprovalType[ApprovalType["ExternalIntegration"] = 4] = "ExternalIntegration";
        return ApprovalType;
      }({});
      _admin.ApprovalType = ApprovalType;
      let ValidationType = /*#__PURE__*/function (ValidationType) {
        ValidationType[ValidationType["None"] = 0] = "None";
        ValidationType[ValidationType["ElevenHourRule"] = 1] = "ElevenHourRule";
        ValidationType[ValidationType["FourtyEightHourRule"] = 2] = "FourtyEightHourRule";
        ValidationType[ValidationType["AbsenceInWorkHours"] = 3] = "AbsenceInWorkHours";
        return ValidationType;
      }({});
      _admin.ValidationType = ValidationType;
      let ConfigurationType = /*#__PURE__*/function (ConfigurationType) {
        ConfigurationType[ConfigurationType["Global"] = 0] = "Global";
        return ConfigurationType;
      }({});
      _admin.ConfigurationType = ConfigurationType;
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["ValidationRule"] = "trix.admin.ValidationRule";
        Entity["RegistrationGroup"] = "trix.admin.RegistrationGroup";
        Entity["RegistrationType"] = "trix.admin.RegistrationType";
        Entity["Configuration"] = "trix.admin.Configuration";
        return Entity;
      }({});
      _admin.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["ValidationRule"] = "ValidationRule";
        SanitizedEntity["RegistrationGroup"] = "RegistrationGroup";
        SanitizedEntity["RegistrationType"] = "RegistrationType";
        SanitizedEntity["Configuration"] = "Configuration";
        return SanitizedEntity;
      }({});
      _admin.SanitizedEntity = SanitizedEntity;
    })(admin || (admin = _trix2.admin || (_trix2.admin = {})));
  })(trix || (trix = {}));
  (function (_trix) {
    let common;
    (function (_common) {
      let types;
      (function (_types) {
        let Entity = /*#__PURE__*/function (Entity) {
          Entity["EnumPair"] = "trix.common.types.EnumPair";
          return Entity;
        }({});
        _types.Entity = Entity;
        let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
          SanitizedEntity["EnumPair"] = "EnumPair";
          return SanitizedEntity;
        }({});
        _types.SanitizedEntity = SanitizedEntity;
      })(types || (types = _common.types || (_common.types = {})));
    })(common || (common = _trix.common || (_trix.common = {})));
  })(trix || (trix = {}));
  let sap;
  (function (_sap) {
    let common;
    (function (_common2) {
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["Languages"] = "sap.common.Languages";
        Entity["Countries"] = "sap.common.Countries";
        Entity["Currencies"] = "sap.common.Currencies";
        Entity["Texts"] = "sap.common.Currencies.texts";
        return Entity;
      }({});
      _common2.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["Languages"] = "Languages";
        SanitizedEntity["Countries"] = "Countries";
        SanitizedEntity["Currencies"] = "Currencies";
        SanitizedEntity["Texts"] = "Texts";
        return SanitizedEntity;
      }({});
      _common2.SanitizedEntity = SanitizedEntity;
    })(common || (common = _sap.common || (_sap.common = {})));
  })(sap || (sap = {}));
  let TrixAdminService;
  (function (_TrixAdminService) {
    let FuncGetApprovalTypes = /*#__PURE__*/function (FuncGetApprovalTypes) {
      FuncGetApprovalTypes["name"] = "getApprovalTypes";
      return FuncGetApprovalTypes;
    }({});
    _TrixAdminService.FuncGetApprovalTypes = FuncGetApprovalTypes;
    let FuncGetValidationTypes = /*#__PURE__*/function (FuncGetValidationTypes) {
      FuncGetValidationTypes["name"] = "getValidationTypes";
      return FuncGetValidationTypes;
    }({});
    _TrixAdminService.FuncGetValidationTypes = FuncGetValidationTypes;
    let FuncGetConfigurationTypes = /*#__PURE__*/function (FuncGetConfigurationTypes) {
      FuncGetConfigurationTypes["name"] = "getConfigurationTypes";
      return FuncGetConfigurationTypes;
    }({});
    _TrixAdminService.FuncGetConfigurationTypes = FuncGetConfigurationTypes;
    let FuncGetRegistrationGroups = /*#__PURE__*/function (FuncGetRegistrationGroups) {
      FuncGetRegistrationGroups["name"] = "getRegistrationGroups";
      return FuncGetRegistrationGroups;
    }({});
    _TrixAdminService.FuncGetRegistrationGroups = FuncGetRegistrationGroups;
    let Entity = /*#__PURE__*/function (Entity) {
      Entity["ConfigurationSet"] = "TrixAdminService.ConfigurationSet";
      Entity["RegistrationGroupSet"] = "TrixAdminService.RegistrationGroupSet";
      Entity["RegistrationTypeSet"] = "TrixAdminService.RegistrationTypeSet";
      Entity["ValidationRuleSet"] = "TrixAdminService.ValidationRuleSet";
      return Entity;
    }({});
    _TrixAdminService.Entity = Entity;
    let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
      SanitizedEntity["ConfigurationSet"] = "ConfigurationSet";
      SanitizedEntity["RegistrationGroupSet"] = "RegistrationGroupSet";
      SanitizedEntity["RegistrationTypeSet"] = "RegistrationTypeSet";
      SanitizedEntity["ValidationRuleSet"] = "ValidationRuleSet";
      return SanitizedEntity;
    }({});
    _TrixAdminService.SanitizedEntity = SanitizedEntity;
  })(TrixAdminService || (TrixAdminService = {}));
  var Entity = /*#__PURE__*/function (Entity) {
    return Entity;
  }(Entity || {});
  var SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
    return SanitizedEntity;
  }(SanitizedEntity || {});
  var __exports = {
    __esModule: true
  };
  __exports.Entity = Entity;
  __exports.SanitizedEntity = SanitizedEntity;
  __exports.trix = trix;
  __exports.sap = sap;
  __exports.TrixAdminService = TrixAdminService;
  return __exports;
});
//# sourceMappingURL=entities-admin-dbg.js.map
