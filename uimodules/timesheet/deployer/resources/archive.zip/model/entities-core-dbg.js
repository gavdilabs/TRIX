"use strict";

sap.ui.define([], function () {
  "use strict";

  let trix;
  (function (_trix3) {
    let core;
    (function (_core) {
      let RecordStatus = /*#__PURE__*/function (RecordStatus) {
        RecordStatus[RecordStatus["Awaiting"] = 0] = "Awaiting";
        RecordStatus[RecordStatus["Processing"] = 1] = "Processing";
        RecordStatus[RecordStatus["Complete"] = 2] = "Complete";
        RecordStatus[RecordStatus["Error"] = 3] = "Error";
        return RecordStatus;
      }({});
      _core.RecordStatus = RecordStatus;
      let RegistrationStatus = /*#__PURE__*/function (RegistrationStatus) {
        RegistrationStatus[RegistrationStatus["InProcess"] = 1] = "InProcess";
        RegistrationStatus[RegistrationStatus["Complete"] = 2] = "Complete";
        RegistrationStatus[RegistrationStatus["Approved"] = 3] = "Approved";
        RegistrationStatus[RegistrationStatus["Rejected"] = 4] = "Rejected";
        return RegistrationStatus;
      }({});
      _core.RegistrationStatus = RegistrationStatus;
      let RegistrationType = /*#__PURE__*/function (RegistrationType) {
        RegistrationType[RegistrationType["Manual"] = 0] = "Manual";
        RegistrationType[RegistrationType["ClockInOut"] = 1] = "ClockInOut";
        return RegistrationType;
      }({});
      _core.RegistrationType = RegistrationType;
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["TimeAllocationGroup"] = "trix.core.TimeAllocationGroup";
        Entity["TimeAllocation"] = "trix.core.TimeAllocation";
        Entity["User"] = "trix.core.User";
        Entity["User2Allocation"] = "trix.core.User2Allocation";
        Entity["TimeRegistration"] = "trix.core.TimeRegistration";
        Entity["WorkSchedule"] = "trix.core.WorkSchedule";
        Entity["WorkWeek"] = "trix.core.WorkWeek";
        Entity["WorkDay"] = "trix.core.WorkDay";
        Entity["Team"] = "trix.core.Team";
        Entity["WeeklyRecording"] = "trix.core.WeeklyRecording";
        Entity["TimeRegistrationEventContext"] = "trix.core.TimeRegistrationEventContext";
        Entity["UserEventContext"] = "trix.core.UserEventContext";
        Entity["AllocationEventContext"] = "trix.core.AllocationEventContext";
        Entity["SolutionConfiguration"] = "trix.core.trix.admin.SolutionConfiguration";
        Entity["ValidationRules"] = "trix.core.trix.admin.ValidationRules";
        Entity["Texts"] = "trix.core.Team.texts";
        return Entity;
      }({});
      _core.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["TimeAllocationGroup"] = "TimeAllocationGroup";
        SanitizedEntity["TimeAllocation"] = "TimeAllocation";
        SanitizedEntity["User"] = "User";
        SanitizedEntity["User2Allocation"] = "User2Allocation";
        SanitizedEntity["TimeRegistration"] = "TimeRegistration";
        SanitizedEntity["WorkSchedule"] = "WorkSchedule";
        SanitizedEntity["WorkWeek"] = "WorkWeek";
        SanitizedEntity["WorkDay"] = "WorkDay";
        SanitizedEntity["Team"] = "Team";
        SanitizedEntity["WeeklyRecording"] = "WeeklyRecording";
        SanitizedEntity["TimeRegistrationEventContext"] = "TimeRegistrationEventContext";
        SanitizedEntity["UserEventContext"] = "UserEventContext";
        SanitizedEntity["AllocationEventContext"] = "AllocationEventContext";
        SanitizedEntity["SolutionConfiguration"] = "SolutionConfiguration";
        SanitizedEntity["ValidationRules"] = "ValidationRules";
        SanitizedEntity["Texts"] = "Texts";
        return SanitizedEntity;
      }({});
      _core.SanitizedEntity = SanitizedEntity;
    })(core || (core = _trix3.core || (_trix3.core = {})));
  })(trix || (trix = {}));
  (function (_trix) {
    let common;
    (function (_common) {
      let types;
      (function (_types) {
        let Entity = /*#__PURE__*/function (Entity) {
          Entity["EnumPair"] = "trix.common.types.EnumPair";
          return Entity;
        }({});
        _types.Entity = Entity;
        let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
          SanitizedEntity["EnumPair"] = "EnumPair";
          return SanitizedEntity;
        }({});
        _types.SanitizedEntity = SanitizedEntity;
      })(types || (types = _common.types || (_common.types = {})));
    })(common || (common = _trix.common || (_trix.common = {})));
  })(trix || (trix = {}));
  let sap;
  (function (_sap) {
    let common;
    (function (_common2) {
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["Languages"] = "sap.common.Languages";
        Entity["Countries"] = "sap.common.Countries";
        Entity["Currencies"] = "sap.common.Currencies";
        Entity["Texts"] = "sap.common.Currencies.texts";
        return Entity;
      }({});
      _common2.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["Languages"] = "Languages";
        SanitizedEntity["Countries"] = "Countries";
        SanitizedEntity["Currencies"] = "Currencies";
        SanitizedEntity["Texts"] = "Texts";
        return SanitizedEntity;
      }({});
      _common2.SanitizedEntity = SanitizedEntity;
    })(common || (common = _sap.common || (_sap.common = {})));
  })(sap || (sap = {}));
  (function (_trix2) {
    let admin;
    (function (_admin) {
      let SolutionType = /*#__PURE__*/function (SolutionType) {
        SolutionType[SolutionType["Standalone"] = 0] = "Standalone";
        SolutionType[SolutionType["S4"] = 1] = "S4";
        SolutionType[SolutionType["ECC"] = 2] = "ECC";
        SolutionType[SolutionType["SuccessFactors"] = 3] = "SuccessFactors";
        return SolutionType;
      }({});
      _admin.SolutionType = SolutionType;
      let ApprovalType = /*#__PURE__*/function (ApprovalType) {
        ApprovalType[ApprovalType["Manual"] = 0] = "Manual";
        ApprovalType[ApprovalType["BackgroundJob"] = 1] = "BackgroundJob";
        ApprovalType[ApprovalType["Auto"] = 3] = "Auto";
        ApprovalType[ApprovalType["ExternalIntegration"] = 4] = "ExternalIntegration";
        return ApprovalType;
      }({});
      _admin.ApprovalType = ApprovalType;
      let ValidationType = /*#__PURE__*/function (ValidationType) {
        ValidationType[ValidationType["None"] = 0] = "None";
        ValidationType[ValidationType["ElevenHourRule"] = 1] = "ElevenHourRule";
        ValidationType[ValidationType["FourtyEightHourRule"] = 2] = "FourtyEightHourRule";
        ValidationType[ValidationType["AbsenceInWorkHours"] = 3] = "AbsenceInWorkHours";
        return ValidationType;
      }({});
      _admin.ValidationType = ValidationType;
      let ConfigurationType = /*#__PURE__*/function (ConfigurationType) {
        ConfigurationType[ConfigurationType["Global"] = 0] = "Global";
        return ConfigurationType;
      }({});
      _admin.ConfigurationType = ConfigurationType;
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["ValidationRule"] = "trix.admin.ValidationRule";
        Entity["RegistrationGroup"] = "trix.admin.RegistrationGroup";
        Entity["RegistrationType"] = "trix.admin.RegistrationType";
        Entity["Configuration"] = "trix.admin.Configuration";
        return Entity;
      }({});
      _admin.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["ValidationRule"] = "ValidationRule";
        SanitizedEntity["RegistrationGroup"] = "RegistrationGroup";
        SanitizedEntity["RegistrationType"] = "RegistrationType";
        SanitizedEntity["Configuration"] = "Configuration";
        return SanitizedEntity;
      }({});
      _admin.SanitizedEntity = SanitizedEntity;
    })(admin || (admin = _trix2.admin || (_trix2.admin = {})));
  })(trix || (trix = {}));
  let TrixCoreService;
  (function (_TrixCoreService) {
    let ITimeRegistrationSet;
    (function (_ITimeRegistrationSet) {
      let actions;
      (function (_actions) {
        let FuncElapsedTime = /*#__PURE__*/function (FuncElapsedTime) {
          FuncElapsedTime["name"] = "elapsedTime";
          return FuncElapsedTime;
        }({});
        _actions.FuncElapsedTime = FuncElapsedTime;
        let ActionValidate = /*#__PURE__*/function (ActionValidate) {
          ActionValidate["name"] = "validate";
          return ActionValidate;
        }({});
        _actions.ActionValidate = ActionValidate;
      })(actions || (actions = _ITimeRegistrationSet.actions || (_ITimeRegistrationSet.actions = {})));
    })(ITimeRegistrationSet || (ITimeRegistrationSet = _TrixCoreService.ITimeRegistrationSet || (_TrixCoreService.ITimeRegistrationSet = {})));
    let ITeamSet;
    (function (_ITeamSet) {
      let actions;
      (function (_actions2) {
        let FuncGetTeamSize = /*#__PURE__*/function (FuncGetTeamSize) {
          FuncGetTeamSize["name"] = "getTeamSize";
          return FuncGetTeamSize;
        }({});
        _actions2.FuncGetTeamSize = FuncGetTeamSize;
      })(actions || (actions = _ITeamSet.actions || (_ITeamSet.actions = {})));
    })(ITeamSet || (ITeamSet = _TrixCoreService.ITeamSet || (_TrixCoreService.ITeamSet = {})));
    let FuncGetRecordStatuses = /*#__PURE__*/function (FuncGetRecordStatuses) {
      FuncGetRecordStatuses["name"] = "getRecordStatuses";
      return FuncGetRecordStatuses;
    }({});
    _TrixCoreService.FuncGetRecordStatuses = FuncGetRecordStatuses;
    let FuncGetRegistrationStatuses = /*#__PURE__*/function (FuncGetRegistrationStatuses) {
      FuncGetRegistrationStatuses["name"] = "getRegistrationStatuses";
      return FuncGetRegistrationStatuses;
    }({});
    _TrixCoreService.FuncGetRegistrationStatuses = FuncGetRegistrationStatuses;
    let FuncGetRegistrationTypes = /*#__PURE__*/function (FuncGetRegistrationTypes) {
      FuncGetRegistrationTypes["name"] = "getRegistrationTypes";
      return FuncGetRegistrationTypes;
    }({});
    _TrixCoreService.FuncGetRegistrationTypes = FuncGetRegistrationTypes;
    let FuncGetAllocationTypes = /*#__PURE__*/function (FuncGetAllocationTypes) {
      FuncGetAllocationTypes["name"] = "getAllocationTypes";
      return FuncGetAllocationTypes;
    }({});
    _TrixCoreService.FuncGetAllocationTypes = FuncGetAllocationTypes;
    let FuncGetActiveUser = /*#__PURE__*/function (FuncGetActiveUser) {
      FuncGetActiveUser["name"] = "getActiveUser";
      return FuncGetActiveUser;
    }({});
    _TrixCoreService.FuncGetActiveUser = FuncGetActiveUser;
    let Entity = /*#__PURE__*/function (Entity) {
      Entity["UserSet"] = "TrixCoreService.UserSet";
      Entity["ManagerSet"] = "TrixCoreService.ManagerSet";
      Entity["TimeAllocationSet"] = "TrixCoreService.TimeAllocationSet";
      Entity["TimeAllocationGroupSet"] = "TrixCoreService.TimeAllocationGroupSet";
      Entity["User2AllocationSet"] = "TrixCoreService.User2AllocationSet";
      Entity["TimeRegistrationSet"] = "TrixCoreService.TimeRegistrationSet";
      Entity["WorkScheduleSet"] = "TrixCoreService.WorkScheduleSet";
      Entity["WorkWeekSet"] = "TrixCoreService.WorkWeekSet";
      Entity["WorkDaySet"] = "TrixCoreService.WorkDaySet";
      Entity["TeamSet"] = "TrixCoreService.TeamSet";
      Entity["Countries"] = "TrixCoreService.Countries";
      Entity["Texts"] = "TrixCoreService.Countries.texts";
      return Entity;
    }({});
    _TrixCoreService.Entity = Entity;
    let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
      SanitizedEntity["UserSet"] = "UserSet";
      SanitizedEntity["ManagerSet"] = "ManagerSet";
      SanitizedEntity["TimeAllocationSet"] = "TimeAllocationSet";
      SanitizedEntity["TimeAllocationGroupSet"] = "TimeAllocationGroupSet";
      SanitizedEntity["User2AllocationSet"] = "User2AllocationSet";
      SanitizedEntity["TimeRegistrationSet"] = "TimeRegistrationSet";
      SanitizedEntity["WorkScheduleSet"] = "WorkScheduleSet";
      SanitizedEntity["WorkWeekSet"] = "WorkWeekSet";
      SanitizedEntity["WorkDaySet"] = "WorkDaySet";
      SanitizedEntity["TeamSet"] = "TeamSet";
      SanitizedEntity["Countries"] = "Countries";
      SanitizedEntity["Texts"] = "Texts";
      return SanitizedEntity;
    }({});
    _TrixCoreService.SanitizedEntity = SanitizedEntity;
  })(TrixCoreService || (TrixCoreService = {}));
  var Entity = /*#__PURE__*/function (Entity) {
    return Entity;
  }(Entity || {});
  var SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
    return SanitizedEntity;
  }(SanitizedEntity || {});
  var __exports = {
    __esModule: true
  };
  __exports.Entity = Entity;
  __exports.SanitizedEntity = SanitizedEntity;
  __exports.trix = trix;
  __exports.sap = sap;
  __exports.TrixCoreService = TrixCoreService;
  return __exports;
});
//# sourceMappingURL=entities-core-dbg.js.map
