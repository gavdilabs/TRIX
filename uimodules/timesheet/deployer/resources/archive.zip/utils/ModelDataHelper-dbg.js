"use strict";

sap.ui.define([], function () {
  "use strict";

  class ModelDataHelper {
    /**
     * Function for getting objects generically
     * @param model Odata Model Instance
     * @param sPath entity path & possible key
     * @param parameters
     * @returns
     */
    static async getModelData(model, sPath, parameters) {
      const objectContext = model.bindContext(sPath, null, parameters).getBoundContext();
      try {
        const result = await objectContext.requestObject();
        return result.value ? result.value : result;
      } catch (error) {
        throw new Error(typeof error === "string" ? error : `Objects Data Request Failed: ${JSON.stringify(error)}`);
      }
    }

    /**
     * Function that allows posting to an Action on the CAP layer
     * @param model Odatamodel to use
     * @param actionName Name of the action to hit
     * @param parameters Parameters structure that will serve as body
     * @returns Result as <K>
     */
    static async postToAction(model, actionName, parameters) {
      const oOperation = model.bindContext(`${actionName}(...)`);
      parameters.forEach(parameter => oOperation.setParameter(parameter.key, parameter.value));
      try {
        await oOperation.execute();
        const result = oOperation.getBoundContext().getObject();
        return result;
      } catch (error) {
        throw new Error(typeof error === "string" ? error : "Request failed");
      }
    }
  }
  return ModelDataHelper;
});
//# sourceMappingURL=ModelDataHelper-dbg.js.map
