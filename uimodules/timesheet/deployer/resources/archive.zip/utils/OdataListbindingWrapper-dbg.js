"use strict";

sap.ui.define([], function () {
  "use strict";

  class OdataListbindingWrapper {
    listBinding = undefined;
    contextsMap = undefined;
    entityKeys = undefined;
    model = undefined;

    /**
     * Wrapper around listbinding
     * @param listBinding Input listbinding to work on
     * @param entityKeys array of the key names for the base entitiy ie ["ID"]
     */
    constructor(listBinding, entityKeys) {
      if (!listBinding) {
        throw new Error("No Listbinding Supplied");
      }
      this.listBinding = listBinding;
      this.model = listBinding?.getModel();
      this.entityKeys = entityKeys;
      this.contextsMap = new Map();
    }

    /**
     * Returns all the contexts in the listbinding at current time
     * @returns Array of Contexts
     */
    async getContexts() {
      void (await this.listBinding.requestContexts());
      return this.listBinding.getContexts();
    }

    /**
     * Request new data remotely on the listbinding
     */
    async refreshBinding(filters) {
      if (filters) {
        this.listBinding.filter(filters);
      } else {
        void (await this.listBinding.requestRefresh());
      }
    }

    /**
     * Function that derives a uinique key for the inner map based on itemData and keys from constructor
     * @param itemData itemdata to create map key from
     * @returns string key
     */
    createMapKeyFromData(itemData) {
      if (!itemData) {
        throw new Error("No data to generate map key from");
      }
      let mapKey = "";
      for (const [key, value] of Object.entries(itemData)) {
        this.entityKeys.forEach(entityKey => {
          if (entityKey === key) {
            mapKey += value;
          }
        });
      }

      //PostProcess Key
      mapKey = mapKey.replaceAll("-", ""); //No -´es
      mapKey = mapKey.length > 50 ? mapKey.substring(0, 50) : mapKey;
      return mapKey;
    }

    /**
     * Create a new item on the listbinding
     * @param newItem body for the create
     * @returns Context from the created item
     */
    async createItem(newItem) {
      try {
        const newContext = this.listBinding.create(newItem);
        void (await newContext.created());
        this.listBinding.refresh();
        return newContext;
      } catch (error) {
        return undefined;
      }
    }

    /**
     * Get specific context object based on the data item
     * @param itemData Data item to look for its context
     * @returns Context or undefined
     */
    getContext(itemData) {
      const mapKey = this.createMapKeyFromData(itemData);
      return this.contextsMap.has(mapKey) ? this.contextsMap.get(mapKey) : undefined;
    }

    /**
     * General purpose function for deleting an item from a list
     * @param itemData data containing atleast key data
     */
    async deleteItem(itemData) {
      let onlyInContext = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      const mapContext = this.getContext(itemData);
      if (mapContext) {
        if (!onlyInContext) {
          await mapContext.delete("$auto");
        }
        this.contextsMap.delete(this.createMapKeyFromData(itemData));
      }
    }
  }
  var __exports = {
    __esModule: true
  };
  __exports.OdataListbindingWrapper = OdataListbindingWrapper;
  return __exports;
});
//# sourceMappingURL=OdataListbindingWrapper-dbg.js.map
