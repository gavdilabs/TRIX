"use strict";

sap.ui.define(["sap/m/MessageBox", "sap/m/MessageToast", "sap/ui/core/message/MessageType", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "sap/ui/model/json/JSONModel", "../model/entities-core", "../utils/DateHelper", "../utils/OdataListbindingWrapper", "./DropDownHandler"], function (MessageBox, MessageToast, MessageType, Filter, FilterOperator, JSONModel, ___model_entities_core, __DateHelper, ___utils_OdataListbindingWrapper, __DropDownHandler) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const trix = ___model_entities_core["trix"];
  const DateHelper = _interopRequireDefault(__DateHelper);
  const OdataListbindingWrapper = ___utils_OdataListbindingWrapper["OdataListbindingWrapper"];
  const DropDownHandler = _interopRequireDefault(__DropDownHandler);
  /**
   * Main data handler for TimeRegistrations. CRUD operations and storing into local JSON models after post processing.
   */
  class TimeRegistrationSetHandler {
    static REGISTRATIONS_MODEL_NAME = "PeriodRegistrations";
    static REGISTRATIONS_GROUP_ID = undefined;
    static instance = undefined;
    static odataModel = undefined;
    static controller = undefined;
    static i18nBundle = undefined;
    static startDate = undefined;
    static endDate = undefined;
    static dataMap = new Map();
    static timeRegistrations = undefined;
    static getInstance() {
      if (!TimeRegistrationSetHandler.odataModel || !TimeRegistrationSetHandler.controller) {
        throw new Error("Cannot create instance w/o initialize() having been called first");
      }
      if (!TimeRegistrationSetHandler.instance) {
        TimeRegistrationSetHandler.instance = new TimeRegistrationSetHandler();
      }
      return TimeRegistrationSetHandler.instance;
    }

    /**
     * Call this once before main use to init the singleton
     * @param odataModel OData V4 model
     * @param controller UI controller
     * @param i18nBundle i18n Resource Bundle for translations
     * @param inputDate Date to start from
     * @param navMode CalendarView Week / Month etc.
     */
    static async initialize(odataModel, controller, i18nBundle, inputDate, navMode) {
      TimeRegistrationSetHandler.odataModel = odataModel;
      TimeRegistrationSetHandler.controller = controller;
      this.i18nBundle = i18nBundle;

      //Update the dates
      void TimeRegistrationSetHandler.updateDatesAndMode(inputDate, navMode, false);

      //Create the listbinding for backend
      const oBinding = odataModel.bindList("/TimeRegistrationSet", undefined, undefined, new Filter("startDate", FilterOperator.NE, null), {
        $$updateGroupId: this.REGISTRATIONS_GROUP_ID,
        $expand: "allocation"
      });
      TimeRegistrationSetHandler.timeRegistrations = new OdataListbindingWrapper(oBinding, ["allocation_ID"]);
      void (await TimeRegistrationSetHandler.timeRegistrations.refreshBinding());
    }

    /**
     * Function to get a specific appointment context by its id
     * @param id Appointment id
     * @returns Context from the listBinding
     */
    async getAppointmentContext(id) {
      const contexts = await TimeRegistrationSetHandler.timeRegistrations.getContexts();
      const context = contexts.find(ctxTmp => ctxTmp.getObject().ID === id);
      return context;
    }

    /**
     * Function that will update an appointment in the backend service
     * @param appointment appointment UI control
     * @param newStartDate new starting date
     * @param newEndDate new ending date
     * @param newAllocationId new allocation id if set (optional)
     */
    async updateAppointment(appointment, newStartDate, newEndDate, newAllocationId) {
      const timeRegData = appointment?.getBindingContext(TimeRegistrationSetHandler.REGISTRATIONS_MODEL_NAME).getObject();
      try {
        timeRegData.startDate = newStartDate;
        timeRegData.endDate = newEndDate;

        //Prepare Map item
        const mapItem = {
          ...timeRegData
        };

        //Update the record in DB
        const startDateStr = DateHelper.dateAsSimpleFormat(newStartDate);
        const startTimeStr = DateHelper.dateAsSimpleTimeFormat(newStartDate);
        const endDateStr = DateHelper.dateAsSimpleFormat(newEndDate);
        const endTimeStr = DateHelper.dateAsSimpleTimeFormat(newEndDate);
        const existingContext = await this.getAppointmentContext(timeRegData.ID);
        void (await existingContext?.setProperty(`${existingContext.getPath()}/startDate`, startDateStr));
        void (await existingContext?.setProperty(`${existingContext.getPath()}/startTime`, startTimeStr));
        void (await existingContext?.setProperty(`${existingContext.getPath()}/endDate`, endDateStr));
        void (await existingContext?.setProperty(`${existingContext.getPath()}/endTime`, endTimeStr));
        if (newAllocationId) {
          void (await existingContext?.setProperty(`${existingContext.getPath()}/allocation_ID`, newAllocationId));
          mapItem.allocation_ID = newAllocationId;
          mapItem.allocation = this.getAllocationById(newAllocationId);
        }
        mapItem.startDate = newStartDate;
        mapItem.endDate = newEndDate;
        TimeRegistrationSetHandler.dataMap.set(timeRegData.ID, mapItem);
        this.updateUIModel();
        this.toast("MessageAppointmentUpdatedOk");
      } catch (e) {
        this.message(TimeRegistrationSetHandler.i18nBundle.getText("MessageAppointmentUpdatedFail"), MessageType.Error);
      }
    }

    /**
     * For new creations ids have a TEMP indicator. This function will determin if an item is TEMP by its ID
     * @param id Id string to check
     * @returns boolean true | false
     */
    static isTempItemId(id) {
      return id && id.indexOf("TEMP#") > -1;
    }

    /**
     * Call this to create a new appointment in the UI only.
     * @param startDate
     * @param endDate
     * @returns
     */
    createTemporaryAppointMent(startDate, endDate, comment) {
      //Create the new UI element
      const itemID = `TEMP#${this.uniqueId()}`;
      const newTempItem = {
        ID: itemID,
        startDate: startDate,
        endDate: endDate,
        startTime: startDate,
        endTime: endDate,
        wholeDay: false,
        amount: 0,
        registrationStatus: trix.core.RegistrationStatus.InProcess,
        registrationType: trix.core.RegistrationType.Manual,
        comment: comment ? comment : "",
        invalid: false,
        statusContext: null,
        recordStatus: trix.core.RecordStatus.Processing,
        user_userID: "TAG"
      };
      TimeRegistrationSetHandler.dataMap.set(itemID, newTempItem);
      this.updateUIModel();
      return newTempItem;
    }

    /**
     * Tooling for getting a uuid
     * @param length 16 in length - default
     * @returns uuid
     */
    uniqueId() {
      let length = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 16;
      return Math.ceil(Math.random() * Date.now()).toPrecision(length).toString().replace(".", "");
    }

    /**
     * Creates an item in the backend
     * @param startDate start date for the appointment
     * @param endDate end date for the appointment
     * @param appointmentData main payload for the appointment
     */
    async createAppointmentBackend(startDate, endDate, appointmentData) {
      const tempId = appointmentData.ID;
      delete appointmentData.ID;

      //Create the record in DB
      const newItemFromBackendContext = await TimeRegistrationSetHandler.timeRegistrations.createItem({
        ...appointmentData,
        startDate: DateHelper.dateAsSimpleFormat(startDate),
        //Workaround hack to cast it
        endDate: DateHelper.dateAsSimpleFormat(endDate),
        startTime: DateHelper.dateAsSimpleTimeFormat(startDate),
        endTime: DateHelper.dateAsSimpleTimeFormat(endDate)
      });
      try {
        //Add the DB Record to the data map
        void (await newItemFromBackendContext.created());

        //Reload the screen data
        void this.loadTimeRegistrations();

        //Delete the temp id item - will update the model automatically
        this.deleteDataMapItem(tempId);
        this.toast("MessageAppointmentCreatedOk");
      } catch {
        this.message("MessageAppointmentCreateFail", MessageType.Error);
      }
    }

    /**
     * Function to delete a specific item from the dataMap
     * @param itemId id to delete
     * @param skipUpdate Default false, flag to skip the model update.
     */
    deleteDataMapItem(itemId) {
      let skipUpdate = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      //Remove the temp record
      TimeRegistrationSetHandler.dataMap.delete(itemId);
      if (skipUpdate === false) {
        this.updateUIModel();
      }
    }

    /**
     * Function delete remote db item
     * @param timeData
     */
    async deleteTimeRegistration(timeData) {
      if (!timeData || !timeData.ID) {
        return;
      }
      const contextToDelete = await this.getAppointmentContext(timeData.ID);
      try {
        if (contextToDelete) {
          await contextToDelete.delete();
        }
        this.deleteDataMapItem(timeData.ID);
        this.toast("MessageAppointmentDeletedOk");
      } catch (e) {
        this.message("MessageAppointmentDeletedFail", MessageType.Error);
      }
    }

    /**
     * Show a toast message
     * @param messageId i18n key
     */
    toast(messageId) {
      MessageToast.show(TimeRegistrationSetHandler.i18nBundle.getText(messageId));
    }

    /**
     * Show a popup message
     * @param messageId i18n key
     * @param type error | warning | info | success
     */
    message(messageId, type) {
      const message = TimeRegistrationSetHandler.i18nBundle.getText(messageId);
      switch (type) {
        case MessageType.Error:
          MessageBox.error(message);
          break;
        case MessageType.Warning:
          MessageBox.warning(message);
          break;
        case MessageType.Information:
          MessageBox.information(message);
          break;
        case MessageType.Success:
          MessageBox.success(message);
          break;
        default:
          MessageBox.show(message);
          break;
      }
    }

    /**
     * Function to externally/internally set the current key dat for the Calendar View and refresh data if flag is not disabled
     * @param inputDate Key date to read data from
     * @param navMode CalendarView Week | Month | Day
     * @param reload default = true. Shoudl reload data after setting.?
     */
    static async updateDatesAndMode(inputDate, navMode) {
      let reload = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
      const [startDate, endDate] = DateHelper.getStartEndDates(inputDate, navMode);
      TimeRegistrationSetHandler.startDate = startDate;
      TimeRegistrationSetHandler.endDate = endDate;
      if (reload) {
        await TimeRegistrationSetHandler.getInstance().loadTimeRegistrations();
      }
    }

    /**
     * Function that initially loads timeregistrations into map
     */
    async loadTimeRegistrations() {
      const dateFilters = [new Filter("startDate", FilterOperator.GE, DateHelper.dateAsSimpleFormat(TimeRegistrationSetHandler.startDate)), new Filter("endDate", FilterOperator.LE, DateHelper.dateAsSimpleFormat(TimeRegistrationSetHandler.endDate))];
      void (await TimeRegistrationSetHandler.timeRegistrations.refreshBinding(dateFilters));
      let timeRegistrationsForPeriod = await TimeRegistrationSetHandler.timeRegistrations.getContexts();
      timeRegistrationsForPeriod = timeRegistrationsForPeriod.filter(ctx => {
        const itemData = ctx.getObject();
        return itemData.startDate && itemData.endDate;
      });
      timeRegistrationsForPeriod.forEach(ctx => {
        const item = ctx.getObject();
        //Setup the startdate
        let [hour, minute, second] = item.startTime.split(":");
        item.startDate = new Date(item.startDate);
        item.startDate.setHours(parseInt(hour));
        item.startDate.setMinutes(parseInt(minute));
        item.startDate.setSeconds(parseInt(second));

        //Setup the enddate
        [hour, minute, second] = item.endTime.split(":");
        item.endDate = new Date(item.endDate);
        item.endDate.setHours(parseInt(hour));
        item.endDate.setMinutes(parseInt(minute));
        item.endDate.setSeconds(parseInt(second));

        //Add to the map
        TimeRegistrationSetHandler.dataMap.set(item.ID, item);
      });
      this.updateUIModel();
    }

    /**
     * This will inflate the items into
     */
    updateUIModel() {
      TimeRegistrationSetHandler.controller.getView().setModel(new JSONModel(Array.from(TimeRegistrationSetHandler.dataMap.values())), TimeRegistrationSetHandler.REGISTRATIONS_MODEL_NAME);
    }

    /**
     * Return a TimeAllocation object structure from a given timeAllocation id
     * @param allocationId Allocation Id
     * @returns TimeAllocation data
     */
    getAllocationById(allocationId) {
      const allocationData = TimeRegistrationSetHandler.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_SUB_TYPES).getData();
      if (allocationData) {
        return allocationData.find(itemTmp => itemTmp.ID === allocationId);
      } else {
        return undefined;
      }
    }
  }
  return TimeRegistrationSetHandler;
});
//# sourceMappingURL=TimeRegistrationSetHandler-dbg.js.map
