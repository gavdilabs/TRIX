"use strict";

sap.ui.define(["../model/entities-core"], function (___model_entities_core) {
  "use strict";

  const trix = ___model_entities_core["trix"];
  /**
   * Interface that should match the data points available in /model/applicationModel.json
   */
  /**
   * Enum representing the supported Calendar Views for the TRIXCalendar
   */
  var CalendarView = /*#__PURE__*/function (CalendarView) {
    CalendarView["DAY"] = "DayView";
    CalendarView["WEEK"] = "WeekView";
    CalendarView["MONTH"] = "MonthView";
    return CalendarView;
  }(CalendarView || {});
  /**
   * Handler/Helper class for accessing properties on the ApplicationModel configuration JSON.
   */
  class ApplicationModelHandler {
    static APPLICATION_MODEL_NAME = "ApplicationModel";
    static instance = new ApplicationModelHandler();
    modelData = undefined;
    controller = undefined;
    colors = undefined;
    i18nBundle = undefined;

    /**
     * Singleton accessor function
     * @returns self
     */
    static getInstance() {
      return ApplicationModelHandler.instance;
    }

    /**
     * Should be called once to intialize the Singleton
     * @param controller UI Controller
     * @param i18nBundle i18n Resource Bundle Class instance
     */
    initialize(controller, i18nBundle) {
      this.controller = controller;
      this.i18nBundle = i18nBundle;
      if (!this.controller) {
        throw new Error("To initialize the ApplicationModelHandler we need a valid Controller");
      }
      this.modelData = this.controller.getOwnerComponent().getModel(ApplicationModelHandler.APPLICATION_MODEL_NAME).getData();

      //Set the current
      this.setCurrentView(this.getCurrentCalendarView());
    }

    /**
     * Setting the view currently selected in UI
     * @param viewKey CalendarView (Day, Week, Month)
     * @returns void
     */
    setCurrentView(viewKey) {
      if (!viewKey) {
        return;
      }
      const text = `${this.i18nBundle.getText("CalendarView", [this.i18nBundle.getText(`CalendarView${viewKey}`)])}`;
      this.upDateModelDataProperty("/view", viewKey);
      this.upDateModelDataProperty("/viewTitle", text);
    }

    /**
     * Tooling function for easy access to setting a value in the ApplicationModel
     * @param propNameAndPath property name ie. /view or /viewTitle
     * @param value Value to set
     */
    upDateModelDataProperty(propNameAndPath, value) {
      const model = this.controller.getOwnerComponent().getModel(ApplicationModelHandler.APPLICATION_MODEL_NAME);
      model.setProperty(propNameAndPath, value);
    }

    /**
     * Returns the currently selected CalendarView
     * @returns CalendarView ... ie. MonthView, WeekView etc
     */
    getCurrentCalendarView() {
      return this.modelData.view;
    }

    /**
     * Get the configured Hex for the diff. main types of allocation
     * @param appointmentType Allocation Type ie. service, project, absence .. etc.
     * @param isAttendance boolean indicator if its absence from the grouped type Absence&Attendance
     * @returns the configured hex color or default white
     */
    getColorByAllocationType(appointmentType) {
      let isAttendance = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      if (appointmentType === "Attendance") {
        return this.modelData.colors.attendance;
      }
      switch (appointmentType) {
        case trix.core.AllocationType.AbsenceAttendance:
          return isAttendance ? this.modelData.colors.attendance : this.modelData.colors.absence;
        case trix.core.AllocationType.Project:
          return this.modelData?.colors.project;
        case trix.core.AllocationType.Service:
          return this.modelData?.colors.service;
        default:
          return "#FFFFFF";
      }
    }
  }
  ApplicationModelHandler.CalendarView = CalendarView;
  return ApplicationModelHandler;
});
//# sourceMappingURL=ApplicationModelHandler-dbg.js.map
