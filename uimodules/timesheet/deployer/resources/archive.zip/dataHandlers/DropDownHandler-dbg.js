"use strict";

sap.ui.define(["sap/ui/model/json/JSONModel", "../utils/ModelDataHelper"], function (JSONModel, __ModelDataHelper) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ModelDataHelper = _interopRequireDefault(__ModelDataHelper);
  /**
   * Interface for the items in the Allocation Tree
   */
  /**
   * Enum to help break up the Absence&Attendance type into 2 separate in the UI
   */
  var ExtendedAllocationTypes = /*#__PURE__*/function (ExtendedAllocationTypes) {
    ExtendedAllocationTypes["Absence"] = "Absence";
    ExtendedAllocationTypes["Attendance"] = "Attendance";
    return ExtendedAllocationTypes;
  }(ExtendedAllocationTypes || {});
  /**
   * Interface describing an AllocationType when used in the UI
   */
  /**
   * Helper class for the different Dropdown lists - putting data into JSON models for 1 time binding etc having post manipulated the data
   */
  class DropDownHandler {
    static MODELNAME_ALLOCATION_TYPES = "ListAllocationTypes";
    static MODELNAME_ALLOCATION_TYPES_LEGEND = "ListAllocationTypesLegend";
    static MODELNAME_ALLOCATION_SUB_TYPES = "ListAllocationSubTypes";
    static MODELNAME_ALLOCATION_TREE = "TreeAllocations";
    controller = undefined;
    odataModel = undefined;
    constructor(controller, odataModel) {
      this.controller = controller;
      this.odataModel = odataModel;
    }

    /**
     * Function to refresh the allocation types into UI JSON Model
     * @param forceRefresh Will only fetch data 1 time ever - unless u set this to true
     * @returns nothing - data is stored in JSON
     */
    async refreshListAllocationTypes() {
      let forceRefresh = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      if (this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_TYPES) && forceRefresh === false) {
        return;
      }
      const groups = await ModelDataHelper.getModelData(this.odataModel, "/TimeAllocationGroupSet", {});
      const parsedTypes = [];
      if (groups && Array.isArray(groups)) {
        groups.forEach(item => {
          parsedTypes.push({
            key: item.ID,
            value: item.title,
            color: item.hex,
            order: item.order,
            icon: item.icon
          });
        });
        this.controller.getView().setModel(new JSONModel(parsedTypes), DropDownHandler.MODELNAME_ALLOCATION_TYPES);
        return parsedTypes;
      }
      return [];
    }

    /**
     * Return boolean indicator if an allocationType and acc. subtype is Attendance type
     * @param allocationType Project/Service etc
     * @param subtypeId allocation subtype from the AllocationType
     * @returns boolean true | false
     */
    isTimeAllocationAttendance(allocationId) {
      const timeAlloc = this.getTimeAllocationById(allocationId);
      return timeAlloc && timeAlloc.isAbsence ? false : true;
    }

    /**
     * Function for getting a ITimeAllocation Object from cache
     * @param subtypeId id for the allocation suubtype
     * @returns ITimeAllocation object or undefined
     */
    getTimeAllocationById(allocationId) {
      const allTimeAllocs = this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_SUB_TYPES).getData();
      return allTimeAllocs?.find(allocTemp => allocTemp.ID === allocationId);
    }

    /**
     * Function for getting an object ref to a ITimeAllocationGroup object
     * @param groupId string group id
     * @returns ITimeAllocationGroup data
     */
    getTimeAllocationGroupById(groupId) {
      const allTimeAllocGroups = this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_TYPES).getData();
      return allTimeAllocGroups.find(groupTmp => groupTmp.key === groupId);
    }

    /**
     * Function for returning the color configured for the relevant allocation id - if any === white
     * @param allocationId TimeAllocation ID string key
     * @returns hex color (defaults white)
     */
    getTimeAllocationColor(allocationId) {
      const timeAlloc = this.getTimeAllocationById(allocationId);
      if (timeAlloc) {
        const parentGroup = this.getTimeAllocationGroupById(timeAlloc.allocationGroupId);
        return timeAlloc.hex ? timeAlloc.hex : parentGroup?.color ? parentGroup.color : "#FFFFFF";
      } else {
        return "#FFFFFF";
      }
    }

    /**
     * Function for returning the icon configured for the relevant allocation id - if any
     * @param allocationId TimeAllocation ID string key
     * @returns hex color (defaults white)
     */
    getTimeAllocationIcon(allocationId) {
      const timeAlloc = this.getTimeAllocationById(allocationId);
      if (timeAlloc) {
        const parentGroup = this.getTimeAllocationGroupById(timeAlloc.allocationGroupId);
        return timeAlloc.icon ? timeAlloc.icon : parentGroup?.icon ? parentGroup.icon : null;
      } else {
        return null;
      }
    }

    /**
     * Function for getting all the allocation subtypes available from the system
     * @param forceRefresh Will only fetch data 1 time ever - unless u set this to true
     * @returns List/array of Allocation Subtypes
     */
    async refreshListAllocationSubTypes() {
      let forceRefresh = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      if (this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_SUB_TYPES) && forceRefresh === false) {
        return this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_SUB_TYPES).getData();
      }
      const timeAllocations = await ModelDataHelper.getModelData(this.odataModel, "/TimeAllocationSet?$orderby=description", {});
      if (timeAllocations && Array.isArray(timeAllocations)) {
        this.controller.getView().setModel(new JSONModel(timeAllocations), DropDownHandler.MODELNAME_ALLOCATION_SUB_TYPES);
        return timeAllocations;
      } else {
        return [];
      }
    }

    /**
     * Function that builds the allocation tree selection
     * @param forceRefresh Will only fetch data 1 time ever - unless u set this to true
     * @returns Array of IAllocationTreeItem
     */
    async loadAllocationTree() {
      let forceRefresh = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;
      const types = await this.refreshListAllocationTypes(forceRefresh);
      const subTypes = await this.refreshListAllocationSubTypes(forceRefresh);
      if (!types || !subTypes) {
        return [];
      }
      if (this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_TREE) && forceRefresh === false) {
        return this.controller.getView().getModel(DropDownHandler.MODELNAME_ALLOCATION_TREE).getData();
      }
      const addSubtypesToParent = (parentNode, subtypes4Parent) => {
        if (subtypes4Parent) {
          subtypes4Parent.forEach(subtype => {
            parentNode.nodes.push({
              isSelectable: true,
              key: subtype.ID,
              text: subtype.description,
              nodes: []
            });
          });
        }
      };

      //Simple 2 level tree for now - that may change ofc
      const nodesStructure = [];
      types.forEach(type => {
        const parentNode = {
          isSelectable: false,
          key: type.key,
          text: type.value,
          nodes: []
        };

        //Link all children to the parent node
        const subtypes4Parent = subTypes.filter(item => item.allocationGroupId === parentNode.key);
        addSubtypesToParent(parentNode, subtypes4Parent);
        nodesStructure.push(parentNode);
      });
      if (nodesStructure.length > 0) {
        this.controller.getView().setModel(new JSONModel(nodesStructure), DropDownHandler.MODELNAME_ALLOCATION_TREE);
        return nodesStructure;
      }
      return [];
    }
  }
  DropDownHandler.ExtendedAllocationTypes = ExtendedAllocationTypes;
  return DropDownHandler;
});
//# sourceMappingURL=DropDownHandler-dbg.js.map
