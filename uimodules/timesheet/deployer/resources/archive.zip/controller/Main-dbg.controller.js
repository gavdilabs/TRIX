"use strict";

sap.ui.define(["sap/ui/core/Fragment", "../dataHandlers/ApplicationModelHandler", "../dataHandlers/DropDownHandler", "../dataHandlers/TimeRegistrationSetHandler", "../eventHandlers/TRIXCalendarEventHandler", "../utils/DateHelper", "./BaseController", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"], function (Fragment, __ApplicationModelHandler, __DropDownHandler, __TimeRegistrationSetHandler, __TRIXCalendarEventHandler, __DateHelper, __BaseController, Filter, FilterOperator) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ApplicationModelHandler = _interopRequireDefault(__ApplicationModelHandler);
  const DropDownHandler = _interopRequireDefault(__DropDownHandler);
  const TimeRegistrationSetHandler = _interopRequireDefault(__TimeRegistrationSetHandler);
  const TRIXCalendarEventHandler = _interopRequireDefault(__TRIXCalendarEventHandler);
  const DateHelper = _interopRequireDefault(__DateHelper);
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace trix.timesheet.controller
   */
  const Main = BaseController.extend("trix.timesheet.controller.Main", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.ddHandler = undefined;
    },
    /**
     * UI5 Hook Function - Called once on initialization
     */
    onInit: function _onInit() {
      this.getRouter().getRoute("main").attachPatternMatched(() => {
        void this.onPatternMatched();
      }, this);
    },
    getActiveUser: async function _getActiveUser() {
      const oBinding = this.getView().getModel().bindContext("/getActiveUser(...)");
      await oBinding.execute();
      return await oBinding.requestObject();
    },
    setUser: async function _setUser() {
      const activeUser = await this.getActiveUser();
      const header = this.getView().byId("trixHeader");
      header.bindElement({
        path: `/UserSet('${activeUser.userID}')`,
        parameters: {
          $$updateGroupId: "userGroup"
        }
      });
    },
    /**
     * Routing target - only firing if url has /Main
     */
    onPatternMatched: async function _onPatternMatched() {
      //ApplicationModelHandler init
      ApplicationModelHandler.getInstance().initialize(this, this.getResourceBundle());
      await this.setUser();

      //Initialize the Data handler(s)
      void (await TimeRegistrationSetHandler.initialize(this.getOdataModelCore(), this, this.getResourceBundle(), new Date(), ApplicationModelHandler.getInstance().getCurrentCalendarView()));

      //Preload some popup lists
      this.ddHandler = new DropDownHandler(this, this.getOdataModelCore());

      //Preload the allocation tree data
      void (await this.ddHandler.loadAllocationTree());

      //Load last as other dependencies, formatter etc. need to use the ddhandler based on calendar data
      void (await TimeRegistrationSetHandler.getInstance().loadTimeRegistrations());

      //Set the Calendar EventHandler on the Trix Calendar
      this.getCalendarControl()?.setEventHandler(new TRIXCalendarEventHandler(this, this.getCalendarControl()));
    },
    userPressed: async function _userPressed(oEvent) {
      this._userDialog ??= await Fragment.load({
        name: "trix.library.fragments.UserDialog",
        controller: this
      });
      this.getView().addDependent(this._userDialog);
      const oContext = oEvent.getSource().getEventingParent().getBindingContext();
      this.editingUserID = oContext.getProperty("userID");
      this._userDialog.setBindingContext(oContext);
      this._userDialog.open();
      const oFilter = new Filter("user_userID", FilterOperator.EQ, this.editingUserID);
      const oListBinding = this.byId("WorkScheduleList").getBinding("items");
      oListBinding.filter(oFilter);
      oListBinding.isSuspended() ? oListBinding.resume() : oListBinding.refresh();
    },
    onSaveUser: function _onSaveUser(oEvent) {
      const oModel = this.getView().getModel();
      this.getView().setBusy(true);
      try {
        void oModel.submitBatch("userGroup").then(() => {
          this.getView().setBusy(false);
          this._userDialog.close();
        });
      } catch (oError) {
        this.getView().setBusy(false);
      }
    },
    onCloseEditUser: function _onCloseEditUser(oEvent) {
      oEvent.getSource().getEventingParent().close();
    },
    /**
     * Function for gettting a ref to the Calendar Control
     * @returns an instance of a TRIXCalendar UI Control
     */
    getCalendarControl: function _getCalendarControl() {
      return this.byId(this.createId("trixCalendar"));
    },
    /**
     * Formatter: Sets configured color on the appointments
     * @param appointmentSubtypeId Id of the TimeAllocation
     * @returns color #hex
     */
    formatterAppointmentColor: function _formatterAppointmentColor(appointmentSubtypeId) {
      if (!appointmentSubtypeId) {
        return "#FFFFFF";
      } else {
        return this.ddHandler.getTimeAllocationColor(appointmentSubtypeId);
      }
    },
    /**
    	 * Formatter: Sets configured color on the appointments
    	 * @param appointmentSubtypeId Id of the TimeAllocation
    	 * @returns color #hex
    	 */
    formatterAppointmentIcon: function _formatterAppointmentIcon(appointmentSubtypeId) {
      if (!appointmentSubtypeId) {
        return null;
      } else {
        return this.ddHandler.getTimeAllocationIcon(appointmentSubtypeId);
      }
    },
    /**
     * Event Function for the ToggleButton "FullDay | WS Day"
     * @param event Std. UI5 event
     */
    onToggleFullDay: function _onToggleFullDay(event) {
      const params = event.getParameters();
      this.getCalendarControl().setFullDay(params.pressed);
    },
    /**
     * Triggers when Date View is changed on the Calendar
     * @param event std. UI5 event
     */
    onCalendarChange: function _onCalendarChange(event) {
      const params = event.getParameters();
      const calendar = event.getSource();
      const viewKey = calendar.getViewByViewId(calendar.getSelectedView())?.getKey();
      ApplicationModelHandler.getInstance().setCurrentView(viewKey);
      void TimeRegistrationSetHandler.updateDatesAndMode(params.date ? DateHelper.addDaysToDate(params.date, 1) : calendar.getStartDate(), viewKey);
    }
  });
  return Main;
});
//# sourceMappingURL=Main-dbg.controller.js.map
