"use strict";

sap.ui.define(["sap/m/SinglePlanningCalendar", "sap/ui/core/RenderManager", "../eventHandlers/EventTypes"], function (SinglePlanningCalendar, RenderManager, ___eventHandlers_EventTypes) {
  "use strict";

  const AppointmentPopoverMode = ___eventHandlers_EventTypes["AppointmentPopoverMode"];
  /**
   * @namespace trix.timesheet.controls
   */
  /**
   * Extension of sap.m.SinglePlanningCalendar - it can do alot but not everything :)
   */
  const TRIXCalendar = SinglePlanningCalendar.extend("trix.timesheet.controls.TRIXCalendar", {
    /**
     * Call the default rendering manager for the SinglePlanningCalendar
     */
    renderer: RenderManager.getRenderer(SinglePlanningCalendar.prototype),
    metadata: {
      properties: {
        defaultView: {
          type: "string"
        }
      }
    },
    constructor: function _constructor(id, settings) {
      SinglePlanningCalendar.prototype.constructor.call(this, id, settings);
      this.initialized = false;
      this.eventHandler = undefined;
    },
    /**
     * Possible to set an external eventhandler class so as to not flood controllers with event impl functions
     * @param eventHandler ICalendarEventHandler implementation
     */
    setEventHandler: function _setEventHandler(eventHandler) {
      this.eventHandler = eventHandler;

      //Add individual eventhandlers
      //AppointmentDrop?
      if (this.eventHandler.onAppointmentDrop) {
        this.attachAppointmentDrop(event => {
          void this.eventHandler.onAppointmentDrop(event);
        });
      }
      //AppointmentCreate?
      if (this.eventHandler.onAppointmentCreate) {
        this.attachAppointmentCreate(
        //@ts-expect-error: UI5 does not support multiple params on events, but the UI xml does
        (event, mode) => {
          void this.eventHandler.onAppointmentCreate(event, mode ? mode : AppointmentPopoverMode.DRAGGED);
        });
      }
      //Calendar Cell Press
      if (this.eventHandler.onCellPress) {
        this.attachCellPress(event => {
          void this.eventHandler.onCellPress(event, AppointmentPopoverMode.CELLPRESS);
        });
      }
      //OnAppointment selection
      if (this.eventHandler.onAppointmentSelect) {
        this.attachAppointmentSelect(event => {
          void this.eventHandler.onAppointmentSelect(event, AppointmentPopoverMode.SELECTED);
        });
      }

      //Event when an appointment has been resized
      if (this.eventHandler.onAppointmentResize) {
        this.attachAppointmentResize(event => {
          void this.eventHandler.onAppointmentResize(event, AppointmentPopoverMode.RESIZE);
        });
      }
    },
    /**
     * If you need to get the view
     * @param id
     * @returns the View witht that ID or undefined
     */
    getViewByViewId: function _getViewByViewId(id) {
      const views = this.getViews();
      return views?.find(view => view.getId() === id);
    },
    /**
     * Default hook onEfterRendering to take care of default view fx
     * @param oEvent
     */
    onAfterRendering: function _onAfterRendering(oEvent) {
      SinglePlanningCalendar.prototype.onAfterRendering.call(this, oEvent);

      //Handle default view setting (custom)
      if (!this.initialized) {
        if (this.getDefaultView()) {
          this.setSelectedView(this.getViewByKey(this.getDefaultView()));
        }
        this.initialized = true;
      }
    }
  });
  return TRIXCalendar;
});
//# sourceMappingURL=TRIXCalendar-dbg.js.map
