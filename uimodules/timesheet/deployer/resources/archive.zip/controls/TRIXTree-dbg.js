"use strict";

sap.ui.define(["sap/m/Tree", "sap/ui/core/RenderManager"], function (Tree, RenderManager) {
  "use strict";

  /**
   * @namespace trix.timesheet.controls
   */
  /**
   * Extension of standard sap.m.Tree control - we need small tweaks here and there
   */
  const TRIXTree = Tree.extend("trix.timesheet.controls.TRIXTree", {
    /**
     * Use the standard sap.m.Tree rendering manager
     */
    renderer: RenderManager.getRenderer(Tree.prototype),
    metadata: {
      properties: {}
    },
    constructor: function _constructor(id, settings) {
      Tree.prototype.constructor.call(this, id, settings);
    },
    onAfterRendering: function _onAfterRendering(oEvent) {
      Tree.prototype.onAfterRendering.call(this, oEvent);
      this.removeSelections(true); //When being reopened in popover same type cannot be selected w/o this
    }
  });
  return TRIXTree;
});
//# sourceMappingURL=TRIXTree-dbg.js.map
