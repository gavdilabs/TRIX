"use strict";

sap.ui.define([], function () {
  "use strict";

  /**
   * To distinguish btw. in what mode/context an Appointment is created we introduce a second param in the event. This event should be added in the XML mapping. ie. like cellPress="onCellPress($event, 'CELLPRESS')"
   */
  var AppointmentPopoverMode = /*#__PURE__*/function (AppointmentPopoverMode) {
    AppointmentPopoverMode["DRAGGED"] = "DRAGGED";
    AppointmentPopoverMode["SELECTED"] = "SELECTED";
    AppointmentPopoverMode["CELLPRESS"] = "CELLPRESS";
    AppointmentPopoverMode["RESIZE"] = "RESIZE";
    return AppointmentPopoverMode;
  }(AppointmentPopoverMode || {});
  /**
   * Common interface to support a CalendarEventHandler for the TRIXCalendar control.
   */
  var __exports = {
    __esModule: true
  };
  __exports.AppointmentPopoverMode = AppointmentPopoverMode;
  return __exports;
});
//# sourceMappingURL=EventTypes-dbg.js.map
