"use strict";

sap.ui.define(["sap/ui/core/Fragment", "sap/ui/model/json/JSONModel", "../dataHandlers/ApplicationModelHandler", "../dataHandlers/DropDownHandler", "../dataHandlers/TimeRegistrationSetHandler", "./EventTypes"], function (Fragment, JSONModel, __ApplicationModelHandler, __DropDownHandler, __TimeRegistrationSetHandler, ___EventTypes) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const ApplicationModelHandler = _interopRequireDefault(__ApplicationModelHandler);
  const CalendarView = __ApplicationModelHandler["CalendarView"];
  const DropDownHandler = _interopRequireDefault(__DropDownHandler);
  const TimeRegistrationSetHandler = _interopRequireDefault(__TimeRegistrationSetHandler);
  const AppointmentPopoverMode = ___EventTypes["AppointmentPopoverMode"];
  /**
   * Interface(Inner) for controllering the data selected in the appointment popover
   */
  /**
   * Implementation of the ICalendarEventHandler interface - to support modularization of event impl. into sep class to avoid controller flooding etc.
   */
  class TRIXCalendarEventHandler {
    controller = undefined;
    cellPressed = false;
    tempUiRecord = undefined;
    tempAppointmentControl = undefined;
    calendar = undefined;
    POPOVER_MODEL_NAME = "PopoverControl";
    constructor(controller, calendar) {
      this.controller = controller;
      this.calendar = calendar;
    }

    /**
     * Event function for when we move an appointment around and drop it
     * @param event std. ui5 event
     */
    async onAppointmentDrop(event) {
      const parameters = event.getParameters();

      //Update the record in DB
      void (await TimeRegistrationSetHandler.getInstance().updateAppointment(parameters.appointment, parameters.startDate, parameters.endDate));
      return;
    }

    /**
     * Event function for when a Cell is pressed
     * @param event std. ui5 event
     * @param mode param 2 of event to specify which mode we are in
     */
    async onCellPress(event, mode) {
      if (!this.cellPressed) {
        this.cellPressed = true;
        void (await this.onAppointmentCreate(event, mode));
      }
    }

    /**
     * Event: Creates a new Appointment
     * @param event std. base event for UI5.
     */
    async onAppointmentCreate(event, mode) {
      //Check if we should allow registering
      if (!this.canRegister()) {
        return;
      }
      const parameters = event.getParameters();
      this.tempUiRecord = TimeRegistrationSetHandler.getInstance().createTemporaryAppointMent(parameters.startDate, parameters.endDate);
      const appointmentControl = this.getCalendarAppointmentById(this.tempUiRecord.ID, true);
      if (appointmentControl) {
        void (await this.openAppointmentDialogByControl(appointmentControl, mode, 200));
      }
    }

    /**
     * Event function for when an exisiting appointment is resized
     * @param event std. ui5 event
     */
    async onAppointmentResize(event, mode) {
      console.log(mode, event.getParameters());
      const parameters = event.getParameters();

      //Update the record in DB
      void (await TimeRegistrationSetHandler.getInstance().updateAppointment(parameters.appointment, parameters.startDate, parameters.endDate));
      return;
    }

    /**
     * Event function that handles when the project popover closes
     */
    onAppointmentPopoverClose() {
      if (this.tempUiRecord?.ID && TimeRegistrationSetHandler.isTempItemId(this.tempUiRecord.ID)) {
        TimeRegistrationSetHandler.getInstance().deleteDataMapItem(this.tempUiRecord.ID);
      }
      this.cellPressed = false;
    }

    /**
     * Function for getting a specific UI Appointment control in the Calendar
     * @param id id = KEY of the control element to fetch
     * @returns CalendarAppointment or null
     */
    getCalendarAppointmentById(id) {
      let isTemporary = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
      const calendarControl = this.calendar.getAppointments().find(elm => elm.getKey() === id);
      if (isTemporary) {
        calendarControl.setColor("rgba(0, 0, 0, 0.5)");
      }
      return calendarControl;
    }

    /**
     * Function that evaluates based on current states/data if registrations should be allowed
     * @returns boolean true | false
     */
    canRegister() {
      //For now we do not support registrations on Month View - makes little sense.
      if (ApplicationModelHandler.getInstance().getCurrentCalendarView() === CalendarView.MONTH) {
        return false;
      }
      return true;
    }

    /**
     * Function for opening the Time Registration
     * @param openByControl UI Control to link the popover to
     * @param mode Which mode popup is in
     * @param delayInMs MS number (default 0) to wait before opening the popover
     */
    async openAppointmentDialogByControl(openByControl, mode) {
      let delayInMs = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 0;
      //Set the global for return events to use
      this.tempAppointmentControl = openByControl;
      const appointmentData = openByControl.getBindingContext("PeriodRegistrations").getObject();
      this.tempUiRecord = appointmentData;
      if (!this.popoverAppointment) {
        this.popoverAppointment = await Fragment.load({
          id: this.controller.getView().getId(),
          name: "trix.timesheet.view.popovers.PopoverAppointment",
          controller: this
        });
        if (this.popoverAppointment) {
          this.controller.getView().addDependent(this.popoverAppointment);
        }
      }
      if (openByControl && this.popoverAppointment) {
        const openFunc = () => {
          const popover = this.popoverAppointment;
          const data = {
            mode: mode,
            startDate: openByControl.getStartDate(),
            endDate: openByControl.getEndDate(),
            isTemporary: appointmentData?.ID?.indexOf("TEMP") === 0 ? true : false,
            recordId: appointmentData?.ID,
            allocationId: appointmentData?.allocation?.ID,
            allocationDescription: appointmentData?.allocation?.description
          };
          popover.setModel(new JSONModel(data), this.POPOVER_MODEL_NAME);
          popover.openBy(openByControl);
        };
        //To make sure the control has rendered - def. a problem locally
        window.setTimeout(openFunc, delayInMs);
      }
    }

    /**
     * Event Function for when selecting a Tree Project/allocation Item
     * @param event Std. UI5 event
     * @returns void
     */
    onAppointmentPopoverItemSelect(event) {
      const popoverData = this.getPopoverModelData();
      const params = event.getParameters();
      if (!params || !params.listItem) {
        return;
      }
      const selectedItemData = params.listItem.getBindingContext(DropDownHandler.MODELNAME_ALLOCATION_TREE).getObject();

      //Update the selected item key in popover model
      this.setPopoverModelDataProperty("/allocationId", selectedItemData.key);

      //If we are in SELECTD mode we abort here - we dont want the popup to close and create item
      if (popoverData?.mode === AppointmentPopoverMode.SELECTED) {
        return;
      }

      //No data or non-selectable project
      if (!selectedItemData || selectedItemData.isSelectable === false) {
        return;
      }

      //add allocation Id to the tempUiRecord data
      this.tempUiRecord.allocation_ID = selectedItemData.key;

      //Commit the record to th backend DB
      void TimeRegistrationSetHandler.getInstance().createAppointmentBackend(this.tempAppointmentControl.getStartDate(), this.tempAppointmentControl.getEndDate(), this.tempUiRecord);
      this.closePopover();
    }

    /**
     * Event function for when an exisitng appointment is selected
     * @param event
     */
    async onAppointmentSelect(event) {
      const params = event.getParameters();
      if (params && params.appointment) {
        void (await this.openAppointmentDialogByControl(params.appointment, AppointmentPopoverMode.SELECTED));
      }
    }

    /**
     * Function for closing the appointment popover
     */
    closePopover() {
      this.popoverAppointment?.close();
    }

    /**
     * Event function for when save is clicked in the appointment popover
     */
    async onSaveAppointmentChanges() {
      const data = this.getPopoverModelData();

      //We use the below ref dates for stability as the timepickers may go 1970.01.01
      const newStartDate = this.tempAppointmentControl.getStartDate();
      const newEndDate = this.tempAppointmentControl.getEndDate();
      newStartDate.setHours(data.startDate.getHours());
      newStartDate.setMinutes(data.startDate.getMinutes());
      newEndDate.setHours(data.endDate.getHours());
      newEndDate.setMinutes(data.endDate.getMinutes());

      //Update the record in DB
      void (await TimeRegistrationSetHandler.getInstance().updateAppointment(this.tempAppointmentControl, newStartDate, newEndDate, data.allocationId));
      this.closePopover();
    }

    /**
     * Function that handles the deletion of an appointment
     */
    async onDeleteAppointment() {
      const data = this.getPopoverModelData();
      void (await TimeRegistrationSetHandler.getInstance().deleteTimeRegistration({
        ID: data.recordId
      }));
      this.closePopover();
    }

    /**
     * Conv. function to get easy access to the current popover model data
     * @returns IPopupModel data structure
     */
    getPopoverModelData() {
      return this.popoverAppointment.getModel(this.POPOVER_MODEL_NAME).getData();
    }

    /**
     * Set a property value in the PopoverModel
     * @param propName property name to set
     * @param value value to set
     */
    setPopoverModelDataProperty(propName, value) {
      if (!propName) {
        return;
      }
      propName = propName[0] === "/" ? propName : `/${propName}`;
      const model = this.popoverAppointment.getModel(this.POPOVER_MODEL_NAME);
      if (model) {
        model.setProperty(propName, value);
      }
    }
  }
  return TRIXCalendarEventHandler;
});
//# sourceMappingURL=TRIXCalendarEventHandler-dbg.js.map
