//@ui5-bundle trix/reporting/Component-preload.js
sap.ui.require.preload({
	"trix/reporting/Component.js":function(){
"use strict";sap.ui.define(["sap/ui/core/UIComponent","./model/models","sap/ui/Device"],function(t,e,i){"use strict";function s(t){return t&&t.__esModule&&typeof t.default!=="undefined"?t.default:t}const n=s(e);const o=t.extend("trix.reporting.Component",{metadata:{manifest:"json"},init:function e(){t.prototype.init.call(this);this.setModel(n.createDeviceModel(),"device");this.getRouter().initialize()},getContentDensityClass:function t(){if(this.contentDensityClass===undefined){if(document.body.classList.contains("sapUiSizeCozy")||document.body.classList.contains("sapUiSizeCompact")){this.contentDensityClass=""}else if(!i.support.touch){this.contentDensityClass="sapUiSizeCompact"}else{this.contentDensityClass="sapUiSizeCozy"}}return this.contentDensityClass}});return o});
},
	"trix/reporting/controller/App.controller.js":function(){
"use strict";sap.ui.define(["./BaseController"],function(t){"use strict";function e(t){return t&&t.__esModule&&typeof t.default!=="undefined"?t.default:t}const n=e(t);const o=n.extend("trix.reporting.controller.App",{onInit:function t(){this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass())}});return o});
},
	"trix/reporting/controller/BaseController.js":function(){
"use strict";sap.ui.define(["sap/ui/core/mvc/Controller","sap/ui/core/UIComponent","sap/ui/core/routing/History"],function(e,t,n){"use strict";const o=e.extend("trix.reporting.controller.BaseController",{getOwnerComponent:function t(){return e.prototype.getOwnerComponent.call(this)},getRouter:function e(){return t.getRouterFor(this)},getResourceBundle:function e(){const t=this.getOwnerComponent().getModel("i18n");return t.getResourceBundle()},getModel:function e(t){return this.getView().getModel(t)},setModel:function e(t,n){this.getView().setModel(t,n);return this},navTo:function e(t,n,o){this.getRouter().navTo(t,n,undefined,o)},onNavBack:function e(){const t=n.getInstance().getPreviousHash();if(t!==undefined){window.history.go(-1)}else{this.getRouter().navTo("main",{},undefined,true)}}});return o});
},
	"trix/reporting/controller/Main.controller.js":function(){
"use strict";sap.ui.define(["sap/m/MessageBox","./BaseController"],function(e,t){"use strict";function n(e){return e&&e.__esModule&&typeof e.default!=="undefined"?e.default:e}const o=n(t);const r=o.extend("trix.reporting.controller.Main",{sayHello:function t(){e.show("Hello World!")}});return r});
},
	"trix/reporting/i18n/i18n.properties":'appTitle=trix.reporting\nappDescription=UI5 Application trix.reporting\nbtnText=Say Hello\n',
	"trix/reporting/i18n/i18n_de.properties":'appTitle=trix.reporting\nappDescription=UI5 Application trix.reporting\nbtnText=Sag Hallo\n',
	"trix/reporting/i18n/i18n_en.properties":'appTitle=trix.reporting\nappDescription=UI5 Application trix.reporting\nbtnText=Say Hello\n',
	"trix/reporting/manifest.json":'{"_version":"1.12.0","sap.app":{"id":"trix.reporting","type":"application","i18n":"i18n/i18n.properties","title":"{{appTitle}}","description":"{{appDescription}}","applicationVersion":{"version":"1.0.0"}},"sap.ui":{"technology":"UI5","icons":{},"deviceTypes":{"desktop":true,"tablet":true,"phone":true}},"sap.ui5":{"rootView":{"viewName":"trix.reporting.view.App","type":"XML","async":true,"id":"app"},"dependencies":{"minUI5Version":"1.121.0","libs":{"sap.ui.core":{},"sap.m":{}}},"handleValidation":true,"contentDensities":{"compact":true,"cozy":true},"models":{"i18n":{"type":"sap.ui.model.resource.ResourceModel","settings":{"bundleName":"trix.reporting.i18n.i18n"}}},"routing":{"config":{"routerClass":"sap.m.routing.Router","viewType":"XML","viewPath":"trix.reporting.view","controlId":"app","controlAggregation":"pages","async":true},"routes":[{"pattern":"","name":"main","target":"main"}],"targets":{"main":{"viewId":"main","viewName":"Main"}}}}}',
	"trix/reporting/model/formatter.js":function(){
"use strict";sap.ui.define([],function(){"use strict";var e={formatValue:e=>e?.toUpperCase()};return e});
},
	"trix/reporting/model/models.js":function(){
"use strict";sap.ui.define(["sap/ui/model/json/JSONModel","sap/ui/model/BindingMode","sap/ui/Device"],function(e,i,n){"use strict";var s={createDeviceModel:()=>{const s=new e(n);s.setDefaultBindingMode(i.OneWay);return s}};return s});
},
	"trix/reporting/view/App.view.xml":'<mvc:View\n\tcontrollerName="trix.reporting.controller.App"\n\tdisplayBlock="true"\n\txmlns="sap.m"\n\txmlns:mvc="sap.ui.core.mvc"><App id="app" /></mvc:View>\n',
	"trix/reporting/view/Main.view.xml":'<mvc:View\n\tcontrollerName="trix.reporting.controller.Main"\n\tdisplayBlock="true"\n\txmlns="sap.m"\n\txmlns:mvc="sap.ui.core.mvc"\n\txmlns:core="sap.ui.core"\n\tcore:require="{\n\t\tformatter: \'trix/reporting/model/formatter\'\n\t}"><Page\n\t\ttitle="{i18n>appTitle}"\n\t\tid="page"><content><IllustratedMessage\n\t\t\t\ttitle="{i18n>appTitle}"\n\t\t\t\tillustrationType="sapIllus-SuccessHighFive"\n\t\t\t\tenableVerticalResponsiveness="true"\n\t\t\t\tdescription="{i18n>appDescription}"><additionalContent><Button\n\t\t\t\t\t\tid="helloButton"\n\t\t\t\t\t\ttext="{formatter: \'formatter.formatValue\', path: \'i18n>btnText\'}"\n\t\t\t\t\t\tpress="sayHello" /></additionalContent></IllustratedMessage></content></Page></mvc:View>\n'
});
//# sourceMappingURL=Component-preload.js.map
