"use strict";

sap.ui.define(["sap/m/MessageToast", "sap/ui/core/Fragment", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "../model/formatter", "../utils/ModelDataHelper", "./BaseController"], function (MessageToast, Fragment, Filter, FilterOperator, __Formatter, __ModelDataHelper, __BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const Formatter = _interopRequireDefault(__Formatter);
  const ModelDataHelper = _interopRequireDefault(__ModelDataHelper);
  const BaseController = _interopRequireDefault(__BaseController);
  /**
   * @namespace trix.approval.controller
   */
  const Main = BaseController.extend("trix.approval.controller.Main", {
    constructor: function constructor() {
      BaseController.prototype.constructor.apply(this, arguments);
      this.formatter = new Formatter("Formatter");
    },
    /**
     * UI5 Hook Function - Called once on initialization
     */
    onInit: function _onInit() {
      this.getRouter().getRoute("main").attachPatternMatched(() => {
        void this.onPatternMatched();
      }, this);
    },
    /**
     * Routing target - only firing if url has /Main
     */
    onPatternMatched: async function _onPatternMatched() {
      void (await ModelDataHelper.getModelData2JsonModel(this.getOdataModelCore(), "/getRecordStatuses()", this, "RecordStatusList", {}));
    },
    /**
     * Event function for updating a selected record to approved
     * @param oEvent std. UI5 event
     */
    updateRegistrationStatus: async function _updateRegistrationStatus(oEvent) {
      const oBtn = oEvent.getSource();
      const sBtnType = oBtn.getType();
      const iCode = sBtnType === "Success" ? 3 : 4;
      const oRegistration = oBtn.getEventingParent();
      const oTable = oRegistration.getEventingParent();
      if (oTable.getSelectedItems().length > 0) {
        const aItems = oTable.getSelectedItems();
        for (const item of aItems) {
          const oBindingContext = item.getBindingContext();
          await oBindingContext.setProperty("registrationStatus", iCode);
        }
        oTable.getBinding("items").refresh();
      } else {
        const oBindingContext = oRegistration.getBindingContext();
        await oBindingContext.setProperty("registrationStatus", iCode).then(() => {
          oRegistration.getEventingParent().getBinding("items").refresh();
        });
      }
      MessageToast.show(this.getResourceBundle().getText(`reg_status_${iCode}`));
    },
    /**
     * Event function for opening the filter dialog
     * @param oEvent std. ui5 event
     * @returns void
     */
    onOpenFilterPopover: async function _onOpenFilterPopover(oEvent) {
      const oButton = oEvent.getSource();
      const oView = this.getView();
      if (!this.oFilterPopover) {
        this.oFilterPopover = await Fragment.load({
          id: oView.getId(),
          name: "trix.approval.view.dialogs.FilterPopover",
          controller: this
        });
        if (this.oFilterPopover) {
          oView.addDependent(this.oFilterPopover);
          const oFilterComboBox = this.byId("FilterComboBox");
          oFilterComboBox.setSelectedKeys(["1"]);
          this.oFilterPopover.openBy(oButton);
          return;
        }
      }
      if (this.oFilterPopover) {
        oView.addDependent(this.oFilterPopover);
        this.oFilterPopover.openBy(oButton);
      }
    },
    /**
     * Event function for when filter button is hit
     */
    onFilterRegistrations: function _onFilterRegistrations() {
      const oFilterComboBox = this.byId("FilterComboBox"),
        oTable = this.byId("ValidationTable"),
        oBinding = oTable.getBinding("items"),
        aSelectedKeys = oFilterComboBox.getSelectedKeys();
      const aFilters = [];
      for (const key of aSelectedKeys) {
        aFilters.push(new Filter("registrationStatus", FilterOperator.EQ, key));
        if (key === "0") {
          aFilters.push(new Filter("registrationStatus", FilterOperator.EQ, 4));
        }
      }
      oBinding.filter(aFilters);
      oBinding.refresh();
    },
    /**
     * Event function for clearing registration table filters
     */
    onClearRegFilters: function _onClearRegFilters() {
      const oFilterComboBox = this.byId("FilterComboBox"),
        oTable = this.byId("ValidationTable"),
        oBinding = oTable.getBinding("items");
      const aFilters = [];
      oFilterComboBox.setSelectedKeys([]);
      oBinding.filter(aFilters);
      oBinding.refresh();
    },
    /**
     * Event function for when a user is edited - will open popup
     * @param oEvent std. ui5 event
     */
    onEditUser: async function _onEditUser(oEvent) {
      const params = oEvent.getParameters();
      this.editingUserID = params.listItem.getBindingContext().getObject().userID;
      if (!this.dialogEditUser) {
        this.dialogEditUser = await Fragment.load({
          id: this.getView().getId(),
          name: "trix.approval.view.dialogs.EditUserDialog",
          controller: this
        });
      }
      if (!this.dialogEditUser.isOpen()) {
        this.getView().addDependent(this.dialogEditUser);
        this.dialogEditUser.setBindingContext(params.listItem.getBindingContext());
        this.dialogEditUser.open();
        const oFilter = new Filter("user_userID", FilterOperator.EQ, this.editingUserID);
        const oListBinding = this.byId("WorkScheduleList").getBinding("items");
        oListBinding.filter(oFilter);
        oListBinding.isSuspended() ? oListBinding.resume() : oListBinding.refresh();
      }
    },
    /**
     * Event function triggered when edit user popup is closed
     * @param oEvent std ui5 event
     */
    onCloseEditUser: function _onCloseEditUser(oEvent) {
      oEvent.getSource().getEventingParent().close();
    }
  });
  return Main;
});
//# sourceMappingURL=Main-dbg.controller.js.map
