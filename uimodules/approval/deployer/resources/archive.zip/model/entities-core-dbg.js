"use strict";

sap.ui.define([], function () {
  "use strict";

  let trix;
  (function (_trix) {
    let core;
    (function (_core) {
      let RecordStatus = /*#__PURE__*/function (RecordStatus) {
        RecordStatus[RecordStatus["Awaiting"] = 0] = "Awaiting";
        RecordStatus[RecordStatus["Processing"] = 1] = "Processing";
        RecordStatus[RecordStatus["Complete"] = 2] = "Complete";
        RecordStatus[RecordStatus["Error"] = 3] = "Error";
        return RecordStatus;
      }({});
      _core.RecordStatus = RecordStatus;
      let RegistrationStatus = /*#__PURE__*/function (RegistrationStatus) {
        RegistrationStatus[RegistrationStatus["InProcess"] = 1] = "InProcess";
        RegistrationStatus[RegistrationStatus["Complete"] = 2] = "Complete";
        RegistrationStatus[RegistrationStatus["Approved"] = 3] = "Approved";
        RegistrationStatus[RegistrationStatus["Rejected"] = 4] = "Rejected";
        return RegistrationStatus;
      }({});
      _core.RegistrationStatus = RegistrationStatus;
      let RegistrationType = /*#__PURE__*/function (RegistrationType) {
        RegistrationType[RegistrationType["Manual"] = 0] = "Manual";
        RegistrationType[RegistrationType["ClockInOut"] = 1] = "ClockInOut";
        return RegistrationType;
      }({});
      _core.RegistrationType = RegistrationType;
      let AllocationType = /*#__PURE__*/function (AllocationType) {
        AllocationType["Project"] = "Project";
        AllocationType["Service"] = "Service";
        AllocationType["AbsenceAttendance"] = "AbsenceAttendance";
        return AllocationType;
      }({});
      _core.AllocationType = AllocationType;
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["EnumPair"] = "trix.core.EnumPair";
        Entity["TimeAllocation"] = "trix.core.TimeAllocation";
        Entity["User"] = "trix.core.User";
        Entity["User2Allocation"] = "trix.core.User2Allocation";
        Entity["TimeRegistration"] = "trix.core.TimeRegistration";
        Entity["WorkSchedule"] = "trix.core.WorkSchedule";
        Entity["WorkWeek"] = "trix.core.WorkWeek";
        Entity["WorkDay"] = "trix.core.WorkDay";
        Entity["Team"] = "trix.core.Team";
        Entity["Texts"] = "trix.core.Team.texts";
        return Entity;
      }({});
      _core.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["EnumPair"] = "EnumPair";
        SanitizedEntity["TimeAllocation"] = "TimeAllocation";
        SanitizedEntity["User"] = "User";
        SanitizedEntity["User2Allocation"] = "User2Allocation";
        SanitizedEntity["TimeRegistration"] = "TimeRegistration";
        SanitizedEntity["WorkSchedule"] = "WorkSchedule";
        SanitizedEntity["WorkWeek"] = "WorkWeek";
        SanitizedEntity["WorkDay"] = "WorkDay";
        SanitizedEntity["Team"] = "Team";
        SanitizedEntity["Texts"] = "Texts";
        return SanitizedEntity;
      }({});
      _core.SanitizedEntity = SanitizedEntity;
    })(core || (core = _trix.core || (_trix.core = {})));
  })(trix || (trix = {}));
  let sap;
  (function (_sap) {
    let common;
    (function (_common) {
      let Entity = /*#__PURE__*/function (Entity) {
        Entity["Languages"] = "sap.common.Languages";
        Entity["Countries"] = "sap.common.Countries";
        Entity["Currencies"] = "sap.common.Currencies";
        Entity["Texts"] = "sap.common.Currencies.texts";
        return Entity;
      }({});
      _common.Entity = Entity;
      let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
        SanitizedEntity["Languages"] = "Languages";
        SanitizedEntity["Countries"] = "Countries";
        SanitizedEntity["Currencies"] = "Currencies";
        SanitizedEntity["Texts"] = "Texts";
        return SanitizedEntity;
      }({});
      _common.SanitizedEntity = SanitizedEntity;
    })(common || (common = _sap.common || (_sap.common = {})));
  })(sap || (sap = {}));
  let TrixCoreService;
  (function (_TrixCoreService) {
    let IManagerSet;
    (function (_IManagerSet) {
      let actions;
      (function (_actions) {
        let FuncGetTeam = /*#__PURE__*/function (FuncGetTeam) {
          FuncGetTeam["name"] = "getTeam";
          return FuncGetTeam;
        }({});
        _actions.FuncGetTeam = FuncGetTeam;
        let FuncGetReports = /*#__PURE__*/function (FuncGetReports) {
          FuncGetReports["name"] = "getReports";
          return FuncGetReports;
        }({});
        _actions.FuncGetReports = FuncGetReports;
      })(actions || (actions = _IManagerSet.actions || (_IManagerSet.actions = {})));
    })(IManagerSet || (IManagerSet = _TrixCoreService.IManagerSet || (_TrixCoreService.IManagerSet = {})));
    let ITimeRegistrationSet;
    (function (_ITimeRegistrationSet) {
      let actions;
      (function (_actions2) {
        let ActionClockIn = /*#__PURE__*/function (ActionClockIn) {
          ActionClockIn["name"] = "clockIn";
          return ActionClockIn;
        }({});
        _actions2.ActionClockIn = ActionClockIn;
        let ActionClockOut = /*#__PURE__*/function (ActionClockOut) {
          ActionClockOut["name"] = "clockOut";
          return ActionClockOut;
        }({});
        _actions2.ActionClockOut = ActionClockOut;
        let FuncElapsedTime = /*#__PURE__*/function (FuncElapsedTime) {
          FuncElapsedTime["name"] = "elapsedTime";
          return FuncElapsedTime;
        }({});
        _actions2.FuncElapsedTime = FuncElapsedTime;
        let ActionValidate = /*#__PURE__*/function (ActionValidate) {
          ActionValidate["name"] = "validate";
          return ActionValidate;
        }({});
        _actions2.ActionValidate = ActionValidate;
      })(actions || (actions = _ITimeRegistrationSet.actions || (_ITimeRegistrationSet.actions = {})));
    })(ITimeRegistrationSet || (ITimeRegistrationSet = _TrixCoreService.ITimeRegistrationSet || (_TrixCoreService.ITimeRegistrationSet = {})));
    let ITeamSet;
    (function (_ITeamSet) {
      let actions;
      (function (_actions3) {
        let FuncGetTeamSize = /*#__PURE__*/function (FuncGetTeamSize) {
          FuncGetTeamSize["name"] = "getTeamSize";
          return FuncGetTeamSize;
        }({});
        _actions3.FuncGetTeamSize = FuncGetTeamSize;
      })(actions || (actions = _ITeamSet.actions || (_ITeamSet.actions = {})));
    })(ITeamSet || (ITeamSet = _TrixCoreService.ITeamSet || (_TrixCoreService.ITeamSet = {})));
    let FuncGetRecordStatuses = /*#__PURE__*/function (FuncGetRecordStatuses) {
      FuncGetRecordStatuses["name"] = "getRecordStatuses";
      return FuncGetRecordStatuses;
    }({});
    _TrixCoreService.FuncGetRecordStatuses = FuncGetRecordStatuses;
    let FuncGetRegistrationStatuses = /*#__PURE__*/function (FuncGetRegistrationStatuses) {
      FuncGetRegistrationStatuses["name"] = "getRegistrationStatuses";
      return FuncGetRegistrationStatuses;
    }({});
    _TrixCoreService.FuncGetRegistrationStatuses = FuncGetRegistrationStatuses;
    let FuncGetRegistrationTypes = /*#__PURE__*/function (FuncGetRegistrationTypes) {
      FuncGetRegistrationTypes["name"] = "getRegistrationTypes";
      return FuncGetRegistrationTypes;
    }({});
    _TrixCoreService.FuncGetRegistrationTypes = FuncGetRegistrationTypes;
    let FuncGetAllocationTypes = /*#__PURE__*/function (FuncGetAllocationTypes) {
      FuncGetAllocationTypes["name"] = "getAllocationTypes";
      return FuncGetAllocationTypes;
    }({});
    _TrixCoreService.FuncGetAllocationTypes = FuncGetAllocationTypes;
    let Entity = /*#__PURE__*/function (Entity) {
      Entity["UserSet"] = "TrixCoreService.UserSet";
      Entity["ManagerSet"] = "TrixCoreService.ManagerSet";
      Entity["TimeAllocationSet"] = "TrixCoreService.TimeAllocationSet";
      Entity["User2AllocationSet"] = "TrixCoreService.User2AllocationSet";
      Entity["TimeRegistrationSet"] = "TrixCoreService.TimeRegistrationSet";
      Entity["WorkScheduleSet"] = "TrixCoreService.WorkScheduleSet";
      Entity["WorkWeekSet"] = "TrixCoreService.WorkWeekSet";
      Entity["WorkDaySet"] = "TrixCoreService.WorkDaySet";
      Entity["TeamSet"] = "TrixCoreService.TeamSet";
      Entity["Texts"] = "TrixCoreService.TeamSet.texts";
      return Entity;
    }({});
    _TrixCoreService.Entity = Entity;
    let SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
      SanitizedEntity["UserSet"] = "UserSet";
      SanitizedEntity["ManagerSet"] = "ManagerSet";
      SanitizedEntity["TimeAllocationSet"] = "TimeAllocationSet";
      SanitizedEntity["User2AllocationSet"] = "User2AllocationSet";
      SanitizedEntity["TimeRegistrationSet"] = "TimeRegistrationSet";
      SanitizedEntity["WorkScheduleSet"] = "WorkScheduleSet";
      SanitizedEntity["WorkWeekSet"] = "WorkWeekSet";
      SanitizedEntity["WorkDaySet"] = "WorkDaySet";
      SanitizedEntity["TeamSet"] = "TeamSet";
      SanitizedEntity["Texts"] = "Texts";
      return SanitizedEntity;
    }({});
    _TrixCoreService.SanitizedEntity = SanitizedEntity;
  })(TrixCoreService || (TrixCoreService = {}));
  var Entity = /*#__PURE__*/function (Entity) {
    return Entity;
  }(Entity || {});
  var SanitizedEntity = /*#__PURE__*/function (SanitizedEntity) {
    return SanitizedEntity;
  }(SanitizedEntity || {});
  var __exports = {
    __esModule: true
  };
  __exports.Entity = Entity;
  __exports.SanitizedEntity = SanitizedEntity;
  __exports.trix = trix;
  __exports.sap = sap;
  __exports.TrixCoreService = TrixCoreService;
  return __exports;
});
//# sourceMappingURL=entities-core-dbg.js.map
