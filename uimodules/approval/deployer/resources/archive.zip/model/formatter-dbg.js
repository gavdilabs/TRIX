"use strict";

sap.ui.define(["../controller/BaseController"], function (__BaseController) {
  "use strict";

  function _interopRequireDefault(obj) {
    return obj && obj.__esModule && typeof obj.default !== "undefined" ? obj.default : obj;
  }
  const BaseController = _interopRequireDefault(__BaseController);
  class Formatter extends BaseController {
    enableRejectBtn(code) {
      return code === 1 || code === 4 ? true : false;
    }
    enableAcceptBtn(code) {
      return code === 1 || code === 3 ? true : false;
    }
    registrationStatusTxt(code, serverText) {
      const text = this.getResourceBundle().getText(`reg_status_${code}`);
      return text ? text : serverText;
    }
    showApproveRejectBtns(code) {
      return code === 2 ? false : true;
    }
  }
  return Formatter;
});
//# sourceMappingURL=formatter-dbg.js.map
